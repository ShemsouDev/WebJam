window.onbeforeunload = function () {
  window.scrollTo(0, 0);
}